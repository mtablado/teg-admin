(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "./node_modules/rxjs-compat/_esm5/observable/timer.js":
/*!************************************************************!*\
  !*** ./node_modules/rxjs-compat/_esm5/observable/timer.js ***!
  \************************************************************/
/*! exports provided: timer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "timer", function() { return rxjs__WEBPACK_IMPORTED_MODULE_0__["timer"]; });


//# sourceMappingURL=timer.js.map

/***/ }),

/***/ "./src/providers/drivers/drivers.service.ts":
/*!**************************************************!*\
  !*** ./src/providers/drivers/drivers.service.ts ***!
  \**************************************************/
/*! exports provided: DriversService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DriversService", function() { return DriversService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");




// import { oboe } from 'oboe/dist/oboe-browser';

var DriversService = /** @class */ (function () {
    // TODO generate state for drivers to relax the server.
    function DriversService(http) {
        this.http = http;
        this.getDriversURL = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].server_api + '/drivers';
        this.putDriversURL = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].server_api + '/drivers/';
        this.getTrafficURL = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].server_api + '/traffic';
    }
    DriversService.prototype.getDrivers = function () {
        return this.loadData();
    };
    DriversService.prototype.saveDriver = function (driver) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'application/json',
        });
        var options = {
            headers: headers,
        };
        return this.http.patch(this.putDriversURL, driver, options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["retry"])(1));
    };
    DriversService.prototype.traffic = function () {
        return this.requestTraffic();
    };
    DriversService.prototype.requestTraffic = function () {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'application/stream+json',
        });
        var options = {
            headers: headers,
        };
        return this.http.get(this.getTrafficURL, options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["retry"])(1));
    };
    DriversService.prototype.loadData = function () {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'application/stream+json',
        });
        var options = {
            headers: headers,
        };
        return this.http.get(this.getDriversURL, options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["retry"])(1));
    };
    DriversService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], DriversService);
    return DriversService;
}());



/***/ })

}]);
//# sourceMappingURL=common.js.map